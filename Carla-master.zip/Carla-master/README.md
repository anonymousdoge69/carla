<p align="center">
<img src="https://github-readme-stats.vercel.app/api?username=Amarnathcjd&show_icons=true&&theme=tokyonight" />
</p>
